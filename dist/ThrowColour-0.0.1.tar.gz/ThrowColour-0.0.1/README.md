# Title

ThrowColour is a small Python module to make printing messages with formatting and colours easier!

# Overview
Description

  - Feature 1
  - Feature 2


## Usage

In the following paragraphs, I am going to describe how you can get and use Name for your own projects.

###  Getting it

To download scrapeasy, either fork this github repo or simply use Pypi via pip.
```sh
$ pip install ThrowColour
```

### Using it

Exmaple of how to use ThrowColour

```Python
from ThrowColour import cthrow
cthrow('Test 1,2')
```

More details
